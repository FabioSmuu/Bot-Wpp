module.exports = async (bot, msg) => {
	//console.log('[MSG][Recebida]: ' + msg.body)
}